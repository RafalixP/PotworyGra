def get_largest_numbers(numbers):
    numbers.sort()

    return numbers


nums = [2,3,4,1,34,123,21,321,1]

print(nums)
largest = get_largest_numbers(nums)
print(nums)