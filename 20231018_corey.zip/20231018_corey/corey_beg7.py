nums = [1,2,3,4,5]

for num in nums:
    print(num)
    if num == 3:
        print('Found!')
        break


# x = 1

# while x < 20:
#     if x == 5:
#         break
#     print(x)
#     x += 1