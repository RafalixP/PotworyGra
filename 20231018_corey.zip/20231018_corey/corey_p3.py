# Integers and floats
'''
num = 3.14
print(type(num))

print(3 ** 2)
print(3 ** 3)
print(2 ** 3)

num = 1
print(num)
num += 1
print(num)
num *= 10
print(num)

print(round(3.75, -1))

#Comparisons
#Equal:             3 == 2
#Not equal          3 != 2
#Greater then       3 > 2
#Greater or eqal    3 >= 2
'''

num_1 = 3
num_2 = 2

print(num_1 == num_2)
print(num_2 == num_2)
