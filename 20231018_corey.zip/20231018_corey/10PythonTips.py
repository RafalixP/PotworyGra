names = ['Corey', 'Chris', 'Dave', 'Travis']

for numer, name in enumerate(names, start=1):
    print(numer, name)