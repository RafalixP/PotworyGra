import os

# print(dir(os))
print(os.getcwd())

os.chdir('C:/Users/rafal.pieczka/Desktop')

print(os.listdir())

print(os.getcwd())

os.chdir('C:/Users/rafal.pieczka/OneDrive - Accenture/Python_kodo/20231018_corey')

print(os.getcwd())

print(os.listdir())