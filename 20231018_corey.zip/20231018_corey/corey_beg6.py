#Conditionals and booleans


'''language = 'JavaScript'

if language == 'Python':
    print('Language is python')
elif language == 'Java':
    print('Language is java')
elif language == 'JavaScript':
    print('Language is JavaScript')
else: 
    print('No match')'''

'''user = 'Admin'
logged_in = True

if user == 'Admin' and logged_in:
    print('Admin page')
else:
    print('Bad Creds')'''

'''a = [1, 2, 3]
b = [1, 2, 3]

print(id(a))
print(id(b))

print(a is b)
print(a == b)
print(id(a) == id(b))'''

condition = True

if condition:
    print('Evalueated to True')
else:
    print('Evaluated to False')

condition = False

if condition:
    print('Evalueated to True')
else:
    print('Evaluated to False')

condition = 0

if condition:
    print('Evalueated to True')
else:
    print('Evaluated to False')

condition = []

if condition:
    print('Evalueated to True')
else:
    print('Evaluated to False')