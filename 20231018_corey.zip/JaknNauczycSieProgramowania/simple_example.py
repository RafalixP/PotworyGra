
print()

# Define variables
room = "some"
area = 14.0

# if-elif-else construct for room
if room == "kit":
    print("Looking around in the kitchen.")
elif room == "bed":
    print("Looking around in the bedroom.")
else:
    print("Looking around elsewhere.")

# if-elif-else construct for area
if area > 15:
    print("Big place!")
else:
    print("Pretty small.")

print()